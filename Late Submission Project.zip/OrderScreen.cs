﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_fixed_version
{
    public partial class OrderScreen : Form
    {
        private Dictionary<string, string> authorizedUsers;
        public OrderScreen(Dictionary<string, string> users)
        {
            InitializeComponent();
            this.authorizedUsers = users;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /*private void OrderSubmitButton_Click(object sender, EventArgs e)
        {
            
        }*/

        private void OrderSubmitButton_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(GlassQuantity.Text) || string.IsNullOrEmpty(CanQuantity.Text) || string.IsNullOrEmpty(PonyKegQuantity.Text) || string.IsNullOrEmpty(KegQuantity.Text))
            {
                MessageBox.Show("Must enter valid information in all fields!");
            }
            else
            {
                Random rnd = new Random();
                int orderID = rnd.Next(0, 1000000);
                int glassAmount = Int32.Parse(GlassQuantity.Text);
                int cansAmount = Int32.Parse(CanQuantity.Text);
                int ponyAmount = Int32.Parse(PonyKegQuantity.Text);
                int kegAmount = Int32.Parse(KegQuantity.Text);

                string CustomerName = EnterCustomerTextBox.Text;
                string Address = AddressTextBox.Text;

                int totalQuanity = glassAmount + cansAmount + ponyAmount + kegAmount;


                MessageBox.Show($"Total Amount: {totalQuanity} \n" +
                    $"For: {CustomerName} \n" +
                    $"To: {Address}");

                GlassQuantity.Clear();
                CanQuantity.Clear();
                PonyKegQuantity.Clear();
                KegQuantity.Clear();
                EnterCustomerTextBox.Clear();
                AddressTextBox.Clear();

            }

            DialogResult cont = MessageBox.Show("Would you like to continue?", "", MessageBoxButtons.YesNo);
            if (cont == DialogResult.No)
            {
                HomeScreen back = new HomeScreen(authorizedUsers);
                back.Show();
                this.Hide();
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            HomeScreen back = new HomeScreen(authorizedUsers);
            back.Show();
            this.Hide();
        }
    }
}
