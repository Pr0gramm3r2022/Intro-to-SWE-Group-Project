﻿namespace Final_Project_fixed_version
{
    partial class OrderScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            GlassQuantity = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            CanQuantity = new TextBox();
            PonyKegQuantity = new TextBox();
            KegQuantity = new TextBox();
            label6 = new Label();
            label7 = new Label();
            EnterCustomerTextBox = new TextBox();
            AddressTextBox = new TextBox();
            OrderSubmitButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(280, 39);
            label1.Name = "label1";
            label1.Size = new Size(53, 15);
            label1.TabIndex = 0;
            label1.Text = "Quantity";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(237, 60);
            label2.Name = "label2";
            label2.Size = new Size(37, 15);
            label2.TabIndex = 1;
            label2.Text = "Glass:";
            // 
            // GlassQuantity
            // 
            GlassQuantity.Location = new Point(280, 57);
            GlassQuantity.Name = "GlassQuantity";
            GlassQuantity.Size = new Size(100, 23);
            GlassQuantity.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(236, 92);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 3;
            label3.Text = "Cans";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(209, 122);
            label4.Name = "label4";
            label4.Size = new Size(65, 15);
            label4.TabIndex = 4;
            label4.Text = "Pony Kegs:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(237, 147);
            label5.Name = "label5";
            label5.Size = new Size(32, 15);
            label5.TabIndex = 5;
            label5.Text = "Kegs";
            // 
            // CanQuantity
            // 
            CanQuantity.Location = new Point(280, 89);
            CanQuantity.Name = "CanQuantity";
            CanQuantity.Size = new Size(100, 23);
            CanQuantity.TabIndex = 6;
            // 
            // PonyKegQuantity
            // 
            PonyKegQuantity.Location = new Point(280, 118);
            PonyKegQuantity.Name = "PonyKegQuantity";
            PonyKegQuantity.Size = new Size(100, 23);
            PonyKegQuantity.TabIndex = 7;
            // 
            // KegQuantity
            // 
            KegQuantity.Location = new Point(280, 147);
            KegQuantity.Name = "KegQuantity";
            KegQuantity.Size = new Size(100, 23);
            KegQuantity.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(147, 224);
            label6.Name = "label6";
            label6.Size = new Size(127, 15);
            label6.TabIndex = 9;
            label6.Text = "Enter Customer Name:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(190, 256);
            label7.Name = "label7";
            label7.Size = new Size(82, 15);
            label7.TabIndex = 10;
            label7.Text = "Enter Address:";
            // 
            // EnterCustomerTextBox
            // 
            EnterCustomerTextBox.Location = new Point(280, 224);
            EnterCustomerTextBox.Name = "EnterCustomerTextBox";
            EnterCustomerTextBox.Size = new Size(195, 23);
            EnterCustomerTextBox.TabIndex = 11;
            // 
            // AddressTextBox
            // 
            AddressTextBox.Location = new Point(280, 256);
            AddressTextBox.Name = "AddressTextBox";
            AddressTextBox.Size = new Size(195, 23);
            AddressTextBox.TabIndex = 12;
            // 
            // OrderSubmitButton
            // 
            OrderSubmitButton.BackColor = Color.Lime;
            OrderSubmitButton.Location = new Point(342, 285);
            OrderSubmitButton.Name = "OrderSubmitButton";
            OrderSubmitButton.Size = new Size(85, 38);
            OrderSubmitButton.TabIndex = 13;
            OrderSubmitButton.Text = "Submit";
            OrderSubmitButton.UseVisualStyleBackColor = false;
            // 
            // OrderScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(OrderSubmitButton);
            Controls.Add(AddressTextBox);
            Controls.Add(EnterCustomerTextBox);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(KegQuantity);
            Controls.Add(PonyKegQuantity);
            Controls.Add(CanQuantity);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(GlassQuantity);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "OrderScreen";
            Text = "OrderScreen";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox GlassQuantity;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox CanQuantity;
        private TextBox PonyKegQuantity;
        private TextBox KegQuantity;
        private Label label6;
        private Label label7;
        private TextBox EnterCustomerTextBox;
        private TextBox AddressTextBox;
        private Button OrderSubmitButton;
    }
}