﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_fixed_version
{
    public partial class HomeScreen : Form
    {
        private Dictionary<string, string> authorizedUsers;
        public HomeScreen(Dictionary<string, string> users)
        {
            InitializeComponent();
            authorizedUsers = users;
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void NewOrderButton_Click(object sender, EventArgs e)
        {
            OrderScreen order = new OrderScreen(authorizedUsers);
            order.Show();
            this.Hide();
        }

        private void NewCustomerButton_Click(object sender, EventArgs e)
        {
            NewCustomerScreen newCustomer = new NewCustomerScreen(authorizedUsers);
            newCustomer.Show();
            this.Hide();
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            Form1 loginScreen = new Form1();
            loginScreen.Show();
            this.Hide();
        }
    }
}
