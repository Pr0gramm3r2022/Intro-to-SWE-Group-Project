﻿namespace Final_Project_fixed_version
{
    partial class HomeScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            NewOrderButton = new Button();
            NewCustomerButton = new Button();
            LogOutButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(292, 9);
            label1.Name = "label1";
            label1.Size = new Size(170, 15);
            label1.TabIndex = 0;
            label1.Text = "Welcome to Acme Distributing";
            label1.Click += label1_Click;
            // 
            // NewOrderButton
            // 
            NewOrderButton.BackColor = SystemColors.ActiveCaption;
            NewOrderButton.Location = new Point(308, 52);
            NewOrderButton.Name = "NewOrderButton";
            NewOrderButton.Size = new Size(154, 54);
            NewOrderButton.TabIndex = 1;
            NewOrderButton.Text = "New Order";
            NewOrderButton.UseVisualStyleBackColor = false;
            NewOrderButton.Click += NewOrderButton_Click;
            // 
            // NewCustomerButton
            // 
            NewCustomerButton.BackColor = SystemColors.ControlDarkDark;
            NewCustomerButton.Location = new Point(308, 112);
            NewCustomerButton.Name = "NewCustomerButton";
            NewCustomerButton.Size = new Size(154, 49);
            NewCustomerButton.TabIndex = 2;
            NewCustomerButton.Text = "New Customer";
            NewCustomerButton.UseVisualStyleBackColor = false;
            // 
            // LogOutButton
            // 
            LogOutButton.BackColor = Color.Red;
            LogOutButton.Location = new Point(342, 167);
            LogOutButton.Name = "LogOutButton";
            LogOutButton.Size = new Size(83, 30);
            LogOutButton.TabIndex = 3;
            LogOutButton.Text = "Log Out";
            LogOutButton.UseVisualStyleBackColor = false;
            // 
            // HomeScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(LogOutButton);
            Controls.Add(NewCustomerButton);
            Controls.Add(NewOrderButton);
            Controls.Add(label1);
            Name = "HomeScreen";
            Text = "HomeScreen";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button NewOrderButton;
        private Button NewCustomerButton;
        private Button LogOutButton;
    }
}